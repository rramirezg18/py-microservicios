namespace AuthService.Models.Dtos
{
    public class AssignMenusDto
    {
        public List<int> MenuIds { get; set; } = [];
    }
}