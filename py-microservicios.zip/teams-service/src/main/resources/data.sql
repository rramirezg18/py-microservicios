INSERT INTO teams (name, coach, city) VALUES
('Sharks','Laura Martínez','Valencia'),
('Falcons','Diego Herrera','Madrid'),
('Titans','María Gómez','Bilbao'),
('Warriors','Javier Ruiz','Barcelona');
