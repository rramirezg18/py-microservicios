namespace MatchesService.Models.DTOs;

public record ReprogramarDto(
    DateTime NewDate
);
